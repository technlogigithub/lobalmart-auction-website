<?php

namespace App\Http\Middleware;

use Closure;
use DB;
use Location;
use URL;

class ActivityLog
{
	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @param  string|null  $guard
	 * @return mixed
	 */
	
	public function handle($request, Closure $next)
	{
		$currentURL = URL::current();
		$ip = $request->ip();
		$data = Location::get($ip);
		
		$uid = 0;
		$uType = 'Unknown';
		if(session()->get('login_user_59ba36addc2b2f9401580f014c7f58ea4e30989d') != ""){
			$uid = session()->get('login_user_59ba36addc2b2f9401580f014c7f58ea4e30989d');
			$uType = 'User';
		}
		if(session()->get('login_admin_59ba36addc2b2f9401580f014c7f58ea4e30989d') != ""){
			$uid = session()->get('login_admin_59ba36addc2b2f9401580f014c7f58ea4e30989d');
			$uType = 'Admin';
		}
		
		$remark = json_encode($request->all());
		
// 		$response = response()->json($data);
// 		dd($response);


		$url = "/";
		if(session()->get('_previous')['url'] != ""){
			$url = session()->get('_previous')['url'];
		}
				
		$id =  DB::table('activity_logs')->insertGetId([
            'key'=> generateKey(14),
            'user_type'=> $uType,
            'users_id'=> $uid,
            'action' =>  $request->route()->getName(),
            'url'=> $currentURL, 
            'remark' => $remark,
            'status' => 1,
            'system_code'=> $request->ip(),
            'lat' => $data->latitude,
            'long' =>$data->longitude,
            'created_at'=> new \DateTime(),
        ]);

	    return $next($request);
	}
	
	
// 	public function handle($request, Closure $next)
// 	{
// 		$ip = $request->ip();
// 		$data = Location::get($ip);
// 		$uid = 0;
// 		if(session()->get('login_user_59ba36addc2b2f9401580f014c7f58ea4e30989d') != ""){
// 			$uid = session()->get('login_user_59ba36addc2b2f9401580f014c7f58ea4e30989d');
// 		}
// 		$remark = json_encode($request->all());
// 		$url = "/";
// 		if(session()->get('_previous')['url'] != ""){
// 			$url = session()->get('_previous')['url'];
// 		}
// 		$id =  DB::table('activity_logs')->insertGetId([
//             'key'=> generateKey(14),
//             'users_id'=> $uid,
//             'action' =>  $request->route()->getName(),
//             'url'=> $url, 
//             'remark' => $remark,
//             'status' => 1,
//             'system_code'=> $request->ip(),
//             'lat' => $data->latitude,
//             'long' =>$data->longitude,
//             'created_at'=> new \DateTime(),
//         ]);

// 	    return $next($request);
// 	}
}