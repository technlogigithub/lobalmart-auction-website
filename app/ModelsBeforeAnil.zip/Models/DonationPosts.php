<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DonationPosts extends Model
{
    protected $guarded = [];
	protected $table = 'donation_posts';
}
