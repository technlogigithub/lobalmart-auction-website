<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DonationPostView extends Model
{
    protected $guarded = [];
	protected $table = 'donation_posts_views';
}
